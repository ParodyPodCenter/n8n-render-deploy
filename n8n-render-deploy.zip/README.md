# n8n Render Deploy

Este repositorio contiene todo lo necesario para desplegar n8n en Render con soporte para nodos personalizados.

## Cómo usar

1. Haz fork de este repositorio a tu cuenta de GitHub.
2. Ve a [Render.com](https://render.com) y selecciona "New Web Service".
3. Conecta tu cuenta de GitHub y selecciona este repositorio.
4. Render detectará automáticamente el archivo `render.yaml` y comenzará el despliegue.

## Soporte incluido

- Nodos personalizados (GPT, ElevenLabs, etc.)
- Configuración mínima necesaria para empezar